# Profit Kerja - Proyek Android

Proyek Android native untuk menghitung profit Rp4.000 per cup.

## Fitur
- Tombol +1 cup dan -1 cup
- Profit harian otomatis
- Rekap mingguan dan bulanan
- Riwayat penjualan berdasarkan tanggal
- Penyimpanan lokal di HP, tanpa internet
- Reset penjualan hari ini dengan konfirmasi

## Cara membuat APK lewat HP dengan GitHub
1. Buat akun atau masuk ke GitHub.
2. Buat repository baru bernama `profit-kerja`.
3. Upload seluruh isi folder proyek ini ke repository (termasuk folder tersembunyi `.github/workflows`).
4. Buka tab Actions pada repository.
5. Pilih workflow `Build Profit Kerja APK`, lalu tekan `Run workflow`.
6. Setelah selesai, buka hasil run dan unduh artifact `Profit-Kerja-APK`.
7. Ekstrak ZIP artifact, lalu buka `app-debug.apk` dan izinkan pemasangan dari sumber tersebut bila Android meminta.

Workflow GitHub Actions menggunakan Java 17 dan Gradle 8.9 untuk membangun APK debug. Build pertama memerlukan koneksi internet.

## Catatan
APK debug ini untuk instalasi pribadi dan belum ditandatangani sebagai rilis Play Store.
