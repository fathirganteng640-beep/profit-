package com.profitkerja.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PROFIT_PER_CUP = 4000;
    private SharedPreferences prefs;
    private int cups = 0;
    private TextView cupText, profitText, todayText, weekText, monthText, historyText;
    private LinearLayout root;
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    private String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private String month() { return new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()); }
    private String weekKey() {
        Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.setMinimalDaysInFirstWeek(4);
        return c.get(Calendar.YEAR) + "-W" + c.get(Calendar.WEEK_OF_YEAR);
    }
    private String key(String date) { return "cups_" + date; }
    private int getCups(String date) { return prefs.getInt(key(date), 0); }
    private void saveCups() { prefs.edit().putInt(key(today()), cups).apply(); }
    private String rupiah(long n) { return "Rp" + String.format(Locale.US, "%,d", n).replace(',', '.'); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("profit_kerja_data", MODE_PRIVATE);
        cups = getCups(today());
        buildUi();
        refresh();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(18), dp(22), dp(20));
        root.setBackgroundColor(Color.rgb(246, 248, 246));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = text("Profit Kerja", 28, Color.rgb(18, 95, 56), true);
        content.addView(title, matchWrap());
        TextView sub = text("Penghitung keuntungan jualan", 14, Color.DKGRAY, false);
        content.addView(sub, matchWrap());

        TextView label = text("TOTAL PROFIT HARI INI", 13, Color.GRAY, true);
        LinearLayout.LayoutParams gap = matchWrap(); gap.topMargin = dp(28);
        content.addView(label, gap);
        profitText = text("Rp0", 34, Color.rgb(22, 131, 74), true);
        content.addView(profitText, matchWrap());

        cupText = text("0 cup terjual", 19, Color.BLACK, true);
        LinearLayout.LayoutParams cupLp = matchWrap(); cupLp.topMargin = dp(8);
        content.addView(cupText, cupLp);

        TextView rate = text("Profit per cup: Rp4.000", 15, Color.DKGRAY, false);
        LinearLayout.LayoutParams rateLp = matchWrap(); rateLp.topMargin = dp(8);
        content.addView(rate, rateLp);

        Button plus = new Button(this);
        plus.setText("+1 CUP");
        plus.setTextSize(20);
        plus.setTextColor(Color.WHITE);
        plus.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22,131,74)));
        LinearLayout.LayoutParams plusLp = matchWrap(); plusLp.topMargin = dp(28);
        content.addView(plus, plusLp);
        plus.setOnClickListener(v -> { cups++; saveCups(); refresh(); });

        Button minus = new Button(this);
        minus.setText("-1 CUP / KOREKSI");
        minus.setTextSize(14);
        LinearLayout.LayoutParams minusLp = matchWrap(); minusLp.topMargin = dp(8);
        content.addView(minus, minusLp);
        minus.setOnClickListener(v -> {
            if (cups > 0) { cups--; saveCups(); refresh(); }
            else Toast.makeText(this, "Jumlah cup sudah nol", Toast.LENGTH_SHORT).show();
        });

        TextView recap = text("REKAP PENJUALAN", 18, Color.rgb(18,95,56), true);
        LinearLayout.LayoutParams recapLp = matchWrap(); recapLp.topMargin = dp(30);
        content.addView(recap, recapLp);

        todayText = text("", 15, Color.DKGRAY, false);
        content.addView(todayText, matchWrap());
        weekText = text("", 15, Color.DKGRAY, false);
        content.addView(weekText, matchWrap());
        monthText = text("", 15, Color.DKGRAY, false);
        content.addView(monthText, matchWrap());

        Button reset = new Button(this);
        reset.setText("Reset penjualan hari ini");
        LinearLayout.LayoutParams resetLp = matchWrap(); resetLp.topMargin = dp(18);
        content.addView(reset, resetLp);
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Reset penjualan?")
            .setMessage("Jumlah cup hari ini akan diatur menjadi nol. Riwayat hari lain tetap tersimpan.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Reset", (d, w) -> { cups = 0; saveCups(); refresh(); })
            .show());

        historyText = text("", 13, Color.DKGRAY, false);
        LinearLayout.LayoutParams histLp = matchWrap(); histLp.topMargin = dp(20);
        content.addView(historyText, histLp);

        scroll.addView(content);
        root.addView(scroll);
        setContentView(root);
    }

    private void refresh() {
        profitText.setText(rupiah((long)cups * PROFIT_PER_CUP));
        cupText.setText(cups + " cup terjual");
        long todayProfit = (long)getCups(today()) * PROFIT_PER_CUP;
        long weekCups = 0, monthCups = 0;
        Calendar c = Calendar.getInstance();
        int currentWeek = c.get(Calendar.WEEK_OF_YEAR), currentYear = c.get(Calendar.YEAR);
        Map<String, ?> all = prefs.getAll();
        ArrayList<String> history = new ArrayList<>();
        for (String k : all.keySet()) {
            if (!k.startsWith("cups_")) continue;
            String date = k.substring(5);
            int value = prefs.getInt(k, 0);
            if (date.startsWith(month())) monthCups += value;
            try {
                Calendar d = Calendar.getInstance();
                d.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date));
                if (d.get(Calendar.WEEK_OF_YEAR) == currentWeek && d.get(Calendar.YEAR) == currentYear) weekCups += value;
            } catch (Exception ignored) {}
            if (value > 0) history.add(date + " : " + value + " cup — " + rupiah((long)value * PROFIT_PER_CUP));
        }
        Collections.sort(history, Collections.reverseOrder());
        todayText.setText("Hari ini: " + cups + " cup | " + rupiah(todayProfit));
        weekText.setText("Minggu ini: " + weekCups + " cup | " + rupiah(weekCups * PROFIT_PER_CUP));
        monthText.setText("Bulan ini: " + monthCups + " cup | " + rupiah(monthCups * PROFIT_PER_CUP));
        StringBuilder sb = new StringBuilder("RIWAYAT PENJUALAN\n");
        if (history.isEmpty()) sb.append("Belum ada riwayat.");
        else for (int i=0; i<Math.min(history.size(), 15); i++) sb.append(history.get(i)).append("\n");
        historyText.setText(sb.toString());
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
